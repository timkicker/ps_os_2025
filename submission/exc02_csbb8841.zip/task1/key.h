#ifndef KEY_H
#define KEY_H

const char *get_key();

#endif // KEY_H